<?php

// No direct access.
defined('_JEXEC') or die;

?>

<div id="gkTools">
	<a href="#" id="gkToolsInc">A+</a>
	<a href="#" id="gkToolsReset">A</a>
	<a href="#" id="gkToolsDec">A-</a>
</div>